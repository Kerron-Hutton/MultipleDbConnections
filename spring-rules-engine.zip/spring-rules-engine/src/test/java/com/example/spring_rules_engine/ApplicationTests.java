package com.example.spring_rules_engine;

import com.example.spring_rules_engine.models.Fare;
import com.example.spring_rules_engine.models.TaxiRide;
import com.example.spring_rules_engine.services.TaxiFareCalculatorService;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@RequiredArgsConstructor
class ApplicationTests {

  private final TaxiFareCalculatorService service;

  @Test
  void whenNightSurchargeFalseAndDistLessThan10_thenFixWithoutNightSurcharge() {
    val taxiRide = new TaxiRide();

    taxiRide.setIsNightSurcharge(false);
    taxiRide.setDistanceInMile(9L);

  }

}
