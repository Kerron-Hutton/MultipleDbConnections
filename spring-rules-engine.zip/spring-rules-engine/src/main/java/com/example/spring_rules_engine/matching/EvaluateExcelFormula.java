package com.example.spring_rules_engine.matching;

import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Slf4j
public class EvaluateExcelFormula {

  private EvaluateExcelFormula() {}

  public static BigDecimal evaluate(String formula) {
    try (val workbook = new XSSFWorkbook()) {
      val evaluator = workbook.getCreationHelper().createFormulaEvaluator();
      val cell = workbook.createSheet().createRow(0).createCell(0);

      cell.setCellFormula(formula);

      evaluator.evaluateFormulaCell(cell);

      return BigDecimal.valueOf(cell.getNumericCellValue())
        .setScale(4, RoundingMode.HALF_UP);
    } catch (Exception ex) {
      log.error(ex.getMessage());
    }

    return BigDecimal.valueOf(0.00);
  }

}
