package com.example.spring_rules_engine.services;

import com.example.spring_rules_engine.models.Fare;
import com.example.spring_rules_engine.models.TaxiRide;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.kie.api.runtime.KieContainer;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class TaxiFareCalculatorService {

  private final KieContainer kieContainer;

  public Fare calculateFare(TaxiRide taxiRide) {
    val kieSession = kieContainer.newKieSession();
    val rideFare = new Fare();

    kieSession.setGlobal("rideFare", rideFare);
    kieSession.insert(taxiRide);

    kieSession.fireAllRules();
    kieSession.dispose();

    return rideFare;
  }

}
