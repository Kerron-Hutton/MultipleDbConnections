package com.example.spring_rules_engine.matching;

public record DataMap(int accountNumber, String particular, String regexPattern) {}
