package com.example.spring_rules_engine.matching;

import java.util.List;
import java.util.Map;

public abstract class TestData {

  public static final List<DataMap> MAPPING_DATA = List.of(
    new DataMap(601, "603CreditBalance", "603CreditBalance"),
    new DataMap(601, "ncbProofFile", "ncbProofFile"),
    new DataMap(601, "finacleHCL", "finacleHCL"),
    new DataMap(601, "gttumTotal", "gttumTotal"),
    new DataMap(601, "zoneTotal", "^zone.*$")
  );

  public static final List<DataMatch> MATCHING_DATA = List.of(
    new DataMatch(
      601, "601AndUploadsMatchingBalance", "(finacleHCL + ncbProofFile) - (zoneTotal + gttumTotal)"
    ),
    new DataMatch(
      601, "601And630MatchingBalance", "603CreditBalance - zoneTotal"
    )
  );

  public static final Map<String, String> SAMPLE_DATA = Map.of(
    "zone 1-micr", "18348751.91",
    "zone 1-bulk", "278368736.21",
    "zone 2-micr", "5007000.56",
    "zone 2-bulk", "68904749.45",
    "zone3-micr", "0.00",
    "zone3-bulk", "2468747.64",
    "603CreditBalance", "373097985.77",
    "ncbProofFile", "351756574.87",
    "finacleHCL", "23355752.47",
    "gttumTotal", "2014341.57"
  );

  private TestData() {}

}
