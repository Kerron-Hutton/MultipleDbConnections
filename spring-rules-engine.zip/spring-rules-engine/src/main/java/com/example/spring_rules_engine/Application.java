package com.example.spring_rules_engine;

import com.example.spring_rules_engine.models.Fare;
import com.example.spring_rules_engine.models.TaxiRide;
import com.example.spring_rules_engine.services.TaxiFareCalculatorService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RequiredArgsConstructor
@RestController
public class Application {

  private final TaxiFareCalculatorService service;

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

  @PostMapping
  public Fare getTaxiFare(@RequestBody TaxiRide ride) {
    return service.calculateFare(ride);
  }

}
