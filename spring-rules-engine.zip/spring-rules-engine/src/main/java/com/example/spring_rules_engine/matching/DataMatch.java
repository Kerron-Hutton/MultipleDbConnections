package com.example.spring_rules_engine.matching;

public record DataMatch(int accountNumber, String particular, String equation) {}
