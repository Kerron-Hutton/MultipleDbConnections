package com.example.spring_rules_engine.models;

import lombok.Data;

@Data
public class TaxiRide {

  private Boolean isNightSurcharge;

  private Long distanceInMile;

}
