package com.example.spring_rules_engine.models;

import lombok.Data;

@Data
public class Fare {

  private Long nightSurcharge;

  private Long rideFare;

}
