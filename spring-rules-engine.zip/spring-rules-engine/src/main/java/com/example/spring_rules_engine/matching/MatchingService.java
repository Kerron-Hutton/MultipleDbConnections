package com.example.spring_rules_engine.matching;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

@Service
@Slf4j
public class MatchingService {

  @Bean
  public CommandLineRunner runner() {
    return args -> {
      val mappedData = dataMapper(601, TestData.SAMPLE_DATA);
      val matchedData = dataMatching(601, mappedData);

      log.info(
        "\n*** Result Mapped Data ***\n" +
          new ObjectMapper()
            .writerWithDefaultPrettyPrinter()
            .writeValueAsString(mappedData)
      );

      log.info(
        "\n*** Result Matched Data ***\n" +
          new ObjectMapper()
            .writerWithDefaultPrettyPrinter()
            .writeValueAsString(matchedData)
      );
    };
  }

  public Map<String, String> dataMapper(int accountNumber, Map<String, String> data) {
    val mappings = TestData.MAPPING_DATA.stream()
      .filter(m -> m.accountNumber() == accountNumber).toList();

    val result = new HashMap<String, String>();

    for (val map : mappings) {
      for (val entry : data.entrySet()) {
        val isKeyMatched = Pattern.matches(map.regexPattern(), entry.getKey());

        if (isKeyMatched) {
          if (result.containsKey(map.particular())) {
            val currentValue = result.get(map.particular());
            val formula = String.format("%s + %s", currentValue, entry.getValue());

            result.put(
              map.particular(), EvaluateExcelFormula.evaluate(formula).toString()
            );

            continue;
          }

          result.put(map.particular(), entry.getValue());
        }
      }
    }

    return result;
  }

  public Map<String, String> dataMatching(int accountNumber, Map<String, String> mappedData) {
    val matching = TestData.MATCHING_DATA.stream()
      .filter(m -> m.accountNumber() == accountNumber).toList();

    val result = new HashMap<String, String>();

    for (val match : matching) {
      val formula = resolveFormula(match.equation(), mappedData);
      val formulaResult = EvaluateExcelFormula.evaluate(formula);

      log.info(
        String.format("%s = %s", formula, formulaResult.toString())
      );

      result.put(match.particular(), formulaResult.toString());
    }

    return result;
  }

  public String resolveFormula(String equation, Map<String, String> mappedData) {
    val equationChunks = equation.replaceAll("[()]", "").split("[-+*/]");
    var result = equation;

    for (val chunk : equationChunks) {
      val equationKey = chunk.trim();
      val isDataKeyPresent = mappedData.containsKey(equationKey);

      if (isDataKeyPresent) {
        result = result.replaceAll(equationKey, mappedData.get(equationKey));
      }
    }

    return result;
  }

}
