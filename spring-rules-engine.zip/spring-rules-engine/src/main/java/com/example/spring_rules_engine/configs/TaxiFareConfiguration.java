package com.example.spring_rules_engine.configs;

import lombok.val;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.internal.io.ResourceFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

@Service
public class TaxiFareConfiguration {

  private static final String FARE_RULE_DRL = "TAXI_FARE_RULE.drl";

  @Bean
  public KieContainer kieContainer() {
    val kieServices = KieServices.Factory.get();

    val kieFileSystem = kieServices.newKieFileSystem();

    kieFileSystem.write(
      ResourceFactory.newClassPathResource(FARE_RULE_DRL)
    );

    val kieBuilder = kieServices.newKieBuilder(kieFileSystem);
    kieBuilder.buildAll();

    return kieServices.newKieContainer(kieBuilder.getKieModule().getReleaseId());
  }

}
